package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class WorldCup {
	
	public final static String DATA_D = "./data/archivo";
	private Assistant raizAssistant;
	private Participant firstP;
	private int numAssistants;

	
	
	public WorldCup() {
		raizAssistant =null;
		numAssistants = 0;
	}



	public void chargeData(File f) throws IOException, AssistantRepetidoException {
		
		BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        try {

            br = new BufferedReader(new FileReader(f));
            while ((line = br.readLine()) != null) {
            	
                String[] lines = line.split(cvsSplitBy);
                
                	int id = Integer.parseInt(lines[0]);
                	Assistant p = new Assistant(id, lines[1], lines[2], lines[3], lines[4], lines[5], lines[6], lines[7]);
                	if(raizAssistant == null) 
                		raizAssistant = p;
                		
                	else
                		raizAssistant.insert(p);
                	numAssistants++;
                	
                }
              
        } catch (FileNotFoundException e) {
            e.printStackTrace();
	}
        finally {
			try {
				if (br != null)
					br.close();

			} catch (IOException ex) {
				ex.printStackTrace();
			}

        }
	}
	
	 public Assistant getRaizAssistant() {
		return raizAssistant;
	}



	public void setRaizAssistant(Assistant raizAssistant) {
		this.raizAssistant = raizAssistant;
	}



	public Participant getFirstP() {
		return firstP;
	}



	public void setFirstP(Participant firstP) {
		this.firstP = firstP;
	}



	public int getNumAssistants() {
		return numAssistants;
	}



	public void setNumAssistants(int numAssistants) {
		this.numAssistants = numAssistants;
	}



	public Assistant searchAssistant( int aidi){
	        return raizAssistant == null ? null : raizAssistant.search(aidi);
	  }
	 public void loadParticipants(File f) throws IOException {
			String participant = "";
			BufferedReader bf = null;
			try {
				bf = new BufferedReader(new FileReader(f));
						while((participant = bf.readLine()) != null) {
							String[] lines = participant.split(",");
							int id = Integer.parseInt(lines[0]);
							String first = lines[1];
							String last = lines[2];
							String e_mail = lines[3];
							String gender = lines[4];
							String country = lines[5];
							String avatar = lines[6];
							String birthDay = lines[7];
							
							Participant aux = new Participant(id,first,last,e_mail,gender,country,avatar, birthDay);
							addInitialP(aux);
						}
				bf.close();	
			}catch(IOException ioE) {
				ioE.printStackTrace();
			}
		}
		 
		 public void addInitialP(Participant p) {
			if( firstP == null ){
				 firstP = p;
			 }
			 else{
				 p.setNext(firstP);
				 firstP = p;
			 }
		 }
		 
		public Participant searchParticipant(int id) {
		        Participant actual = firstP;
		        while( actual != null && actual.getId( ) != id ) {
		            actual = actual.getNext();
		        }
		        return actual;
		}
	}

