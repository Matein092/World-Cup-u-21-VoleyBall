package model;

public class AssistantRepetidoException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AssistantRepetidoException(int ides) {
		 super( "Ya existe un asistente con ese id: " + ides);
	}

}
