package TestWorldCup;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;

import org.junit.jupiter.api.Test;

import model.Assistant;
import model.AssistantRepetidoException;
import model.WorldCup;

class WorldCupTest {
	
	private WorldCup wc;
	
	public void setUpScenary1() {
		wc = new WorldCup();
		
		
	}
	@Test
	void test() {
		setUpScenary1();
		Assistant a = new Assistant(1000, "Juan", "Perez", "juan@gmail.com", "male", "Mongolia", "s", "31 febrero");
		wc.setRaizAssistant(a);
		assertTrue("Se evaluara que el metodo buscar asistente sea correcto", wc.searchAssistant(a.getId()) == a);
		assertTrue("Se evaluara que el nombre sea el mismo", wc.searchAssistant(a.getId()).getFirst_name().equalsIgnoreCase(a.getFirst_name()));
		assertTrue("Se evaluara que el apellido sea el mismo", wc.searchAssistant(a.getId()).getLast_name().equalsIgnoreCase(a.getLast_name()));
		assertTrue("Se evaluara que el id sea el mismo", wc.searchAssistant(a.getId()).getId() == a.getId());
		assertTrue("Se evaluara que el email sea el mismo", wc.searchAssistant(a.getId()).getEmail().equalsIgnoreCase(a.getEmail()));
		assertTrue("Se evaluara que la foto sea el mismo", wc.searchAssistant(a.getId()).getPhoto().equalsIgnoreCase(a.getPhoto()));
		assertTrue("Se evaluara que el sexo sea el mismo", wc.searchAssistant(a.getId()).getGender().equalsIgnoreCase(a.getGender()));
		assertTrue("Se evaluara que el d�a de nacimiento sea el mismo", wc.searchAssistant(a.getId()).getBirthday().equalsIgnoreCase(a.getBirthday()));
	}

}
