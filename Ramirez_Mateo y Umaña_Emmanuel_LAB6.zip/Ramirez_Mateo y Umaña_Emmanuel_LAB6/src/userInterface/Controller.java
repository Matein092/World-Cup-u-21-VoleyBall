package userInterface;

import java.io.File;
import java.io.IOException;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import model.AssistantRepetidoException;
import model.WorldCup;

public class Controller {
	@FXML
	private Label msgLabel;
	@FXML
	private Label timeLabel;
	@FXML
	private Label msg1Label;
	@FXML
	private Label timeLabel1;
	@FXML
	private Label msg1Label1;
	@FXML
	private Label datosLabel;
	@FXML
	private Button bt1;
	@FXML
	private Button bt2;
	@FXML
	private Button bt3;
	@FXML
	private TextField txt1;
	@FXML
	private TextField txt2;
	@FXML
	private TextField txt3;
	@FXML
	private ImageView img1;
	
	private WorldCup copa;

	public void initialize() {
		copa = new WorldCup();
	}
	public void loadCVS(ActionEvent event) throws IOException, AssistantRepetidoException{
		try {
			FileChooser fch= new FileChooser();
			File f = fch.showOpenDialog(null);
			if(f !=null) {
			txt1.setText(""+f+"");
			copa.chargeData(f);
			copa.loadParticipants(f);
			}
			}catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage());
			}
	}
	public void buscarAssistant(ActionEvent event) throws NullPointerException{
		try {
		long start =  System.currentTimeMillis();
		int intu = Integer.parseInt(txt2.getText());
		Image i = new Image(copa.searchAssistant(intu).getPhoto());
		img1.setImage(i);
		datosLabel.setText(copa.searchAssistant(intu).toString());
		long finale = System.currentTimeMillis();
		timeLabel.setText("time: "+(finale-start)+" ms");
		}catch( Exception e) {
			msg1Label.setText("fatal: el ID ingresado no se encuentra en la base de datos");
		}
		
	}
	public void buscarParticipant(ActionEvent event) throws NullPointerException{
		try {
		long start =  System.currentTimeMillis();
		int inti = Integer.parseInt(txt3.getText());
		Image i = new Image(copa.searchParticipant(inti).getPhoto());
		img1.setImage(i);
		datosLabel.setText(copa.searchParticipant(inti).toString());
		long finale = System.currentTimeMillis();
		timeLabel1.setText("time: "+(finale-start)+" ms");
		}catch( Exception e) {
			msg1Label1.setText("fatal: el ID ingresado no se encuentra en la base de datos");
		}
	}
	
	

}
